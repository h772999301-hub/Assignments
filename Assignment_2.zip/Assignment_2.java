import java.util.*;

public class AssignmentSolutions {

    // --- Question 1: Write a function to reverse a string using Stack ---
    public static String reverseString(String input) {
        Stack<Character> stack = new Stack<>();
        for (char c : input.toCharArray()) {
            stack.push(c);
        }
        StringBuilder reversed = new StringBuilder();
        while (!stack.isEmpty()) {
            reversed.append(stack.pop());
        }
        return reversed.toString();
    }

    // --- Question 2: Write a function to sort a stack using only another Stack ---
    public static void sortStack(Stack<Integer> stack) {
        Stack<Integer> tempStack = new Stack<>();
        while (!stack.isEmpty()) {
            int current = stack.pop();
            while (!tempStack.isEmpty() && tempStack.peek() > current) {
                stack.push(tempStack.pop());
            }
            tempStack.push(current);
        }
        // Transfer back to original stack to have smallest on top
        while (!tempStack.isEmpty()) {
            stack.push(tempStack.pop());
        }
    }

    // --- Question 3: Write a function to reverse the order of elements in a queue ---
    public static void reverseQueue(Queue<Integer> queue) {
        Stack<Integer> stack = new Stack<>();
        while (!queue.isEmpty()) {
            stack.push(queue.poll());
        }
        while (!stack.isEmpty()) {
            queue.add(stack.pop());
        }
    }

    // --- Question 4: Implement a priority queue where the smallest element is dequeue first ---
    // Java's PriorityQueue by default dequeues the smallest element first.
    public static class SmallestFirstPriorityQueue {
        private PriorityQueue<Integer> pq;

        public SmallestFirstPriorityQueue() {
            pq = new PriorityQueue<>(); // Default is min-priority queue
        }

        public void enqueue(int value) {
            pq.add(value);
        }

        public Integer dequeue() {
            return pq.poll();
        }

        public boolean isEmpty() {
            return pq.isEmpty();
        }
    }

    // --- Question 5: Write a function to merge two sorted queues into a single sorted queue ---
    public static Queue<Integer> mergeSortedQueues(Queue<Integer> q1, Queue<Integer> q2) {
        Queue<Integer> merged = new LinkedList<>();
        while (!q1.isEmpty() && !q2.isEmpty()) {
            if (q1.peek() < q2.peek()) {
                merged.add(q1.poll());
            } else {
                merged.add(q2.poll());
            }
        }
        while (!q1.isEmpty()) merged.add(q1.poll());
        while (!q2.isEmpty()) merged.add(q2.poll());
        return merged;
    }

    // --- Main Method for Testing ---
    public static void main(String[] args) {
        System.out.println("--- Question 1: Reverse String ---");
        String original = "Hello";
        System.out.println("Original: " + original);
        System.out.println("Reversed: " + reverseString(original));

        System.out.println("\n--- Question 2: Sort Stack ---");
        Stack<Integer> s = new Stack<>();
        s.push(34); s.push(3); s.push(31); s.push(98);
        System.out.println("Stack before sort: " + s);
        sortStack(s);
        System.out.println("Stack after sort (Smallest on top): " + s);

        System.out.println("\n--- Question 3: Reverse Queue ---");
        Queue<Integer> q = new LinkedList<>(Arrays.asList(1, 2, 3, 4, 5));
        System.out.println("Queue before reverse: " + q);
        reverseQueue(q);
        System.out.println("Queue after reverse: " + q);

        System.out.println("\n--- Question 4: Priority Queue (Smallest First) ---");
        SmallestFirstPriorityQueue pq = new SmallestFirstPriorityQueue();
        pq.enqueue(10); pq.enqueue(5); pq.enqueue(20); pq.enqueue(1);
        System.out.print("Dequeuing from PQ: ");
        while (!pq.isEmpty()) {
            System.out.print(pq.dequeue() + " ");
        }
        System.out.println();

        System.out.println("\n--- Question 5: Merge Sorted Queues ---");
        Queue<Integer> q1 = new LinkedList<>(Arrays.asList(1, 3, 5, 7));
        Queue<Integer> q2 = new LinkedList<>(Arrays.asList(2, 4, 6, 8));
        System.out.println("Q1: " + q1 + ", Q2: " + q2);
        Queue<Integer> merged = mergeSortedQueues(q1, q2);
        System.out.println("Merged Queue: " + merged);
    }
}
